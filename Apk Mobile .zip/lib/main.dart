import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Jual Beli Kucing',
      theme: ThemeData(
        primarySwatch: Colors.orange,
      ),
      home: const JualBeliKucingPage(),
    );
  }
}

class JualBeliKucingPage extends StatefulWidget {
  const JualBeliKucingPage({super.key});

  @override
  State<JualBeliKucingPage> createState() => _JualBeliKucingPageState();
}

class _JualBeliKucingPageState extends State<JualBeliKucingPage> {
  final ImagePicker _picker = ImagePicker();

  File? _fotoKucing;

  final TextEditingController _namaController = TextEditingController();
  final TextEditingController _hargaController = TextEditingController();
  final TextEditingController _deskripsiController = TextEditingController();

  String? namaKucing;
  String? hargaKucing;
  String? deskripsiKucing;

  Future<void> _ambilFotoKucing() async {
    final XFile? foto = await _picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 80,
    );

    if (foto != null) {
      setState(() {
        _fotoKucing = File(foto.path);
      });
    }
  }

  void _simpanDataKucing() {
    setState(() {
      namaKucing = _namaController.text;
      hargaKucing = _hargaController.text;
      deskripsiKucing = _deskripsiController.text;
    });
  }

  @override
  void dispose() {
    _namaController.dispose();
    _hargaController.dispose();
    _deskripsiController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Jual Beli Kucing'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text(
              'Tambah Data Kucing',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 20),

            Container(
              height: 220,
              width: double.infinity,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(12),
              ),
              child: _fotoKucing == null
                  ? const Center(
                child: Text('Belum ada foto kucing'),
              )
                  : ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  _fotoKucing!,
                  fit: BoxFit.cover,
                ),
              ),
            ),

            const SizedBox(height: 12),

            ElevatedButton.icon(
              onPressed: _ambilFotoKucing,
              icon: const Icon(Icons.camera_alt),
              label: const Text('Ambil Foto Kucing'),
            ),

            const SizedBox(height: 20),

            TextField(
              controller: _namaController,
              decoration: const InputDecoration(
                labelText: 'Nama Kucing',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 12),

            TextField(
              controller: _hargaController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Harga Kucing',
                border: OutlineInputBorder(),
                prefixText: 'Rp ',
              ),
            ),

            const SizedBox(height: 12),

            TextField(
              controller: _deskripsiController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Deskripsi Kucing',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 16),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _simpanDataKucing,
                child: const Text('Tampilkan Iklan Kucing'),
              ),
            ),

            const SizedBox(height: 24),

            if (namaKucing != null &&
                hargaKucing != null &&
                deskripsiKucing != null)
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (_fotoKucing != null)
                      ClipRRect(
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(12),
                        ),
                        child: Image.file(
                          _fotoKucing!,
                          height: 220,
                          width: double.infinity,
                          fit: BoxFit.cover,
                        ),
                      ),

                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            namaKucing!,
                            style: const TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          const SizedBox(height: 8),

                          Text(
                            'Rp $hargaKucing',
                            style: const TextStyle(
                              fontSize: 18,
                              color: Colors.orange,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          const SizedBox(height: 8),

                          Text(
                            deskripsiKucing!,
                            style: const TextStyle(fontSize: 16),
                          ),

                          const SizedBox(height: 12),

                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              onPressed: () {},
                              icon: const Icon(Icons.shopping_cart),
                              label: const Text('Beli Sekarang'),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}